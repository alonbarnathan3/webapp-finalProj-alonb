# Agenda

## Build a todo app server using Node.js and Express
## Build a todo app client using pure HTML and JavaScript
## Demonstrate how to use ChatGPT
## Demonstrate how to use GitHub Copilot
